Deploying to Private GKE with Self-Hosted GitHub Runners

✨ Overview

This repository demonstrates how to configure a GitHub Actions workflow to deploy applications to a private Google Kubernetes Engine (GKE) cluster using self-hosted runners. These runners are tagged to ensure workflows execute in a secure, network-restricted environment.

🔒 Why Use Tagged Self-Hosted Runners?

Using self-hosted runners ensures your deployments are:

Secure: No exposure of private clusters or secrets to the public internet.

Internal-Only: Runners can access private endpoints, internal APIs, and VPC-restricted services.

Controlled: Workflows run in a known, trusted, and auditable environment.

We tag these runners with gke-runners to isolate GKE-specific workloads.

⚖️ Workflow Configuration

Example: GitHub Actions Workflow (deploy.yaml)

name: Deploy to GKE

on:
  push:
    branches:
      - main

jobs:
  deploy:
    name: GKE Deployment
    runs-on: [self-hosted, gke-runners]  # Runs only on specified self-hosted runners

    steps:
      - name: Checkout code
        uses: actions/checkout@v3

      - name: Set up gcloud CLI
        uses: google-github-actions/setup-gcloud@v2
        with:
          version: 'latest'

      - name: Authenticate to GCP
        uses: google-github-actions/auth@v2
        with:
          credentials_json: ${{ secrets.GCP_SA_KEY }}

      - name: Configure kubectl context
        run: |
          gcloud container clusters get-credentials ${{ secrets.GKE_CLUSTER_NAME }} \
            --region ${{ secrets.GKE_REGION }} \
            --project ${{ secrets.GCP_PROJECT }}

      - name: Verify GKE access
        run: kubectl get pods --namespace default

🔐 GitHub Secrets Required

Secret Name           Description

GCP_SA_KEY              Base64-encoded service account key JSON

GKE_CLUSTER_NAME        Name of the target GKE cluster

GKE_REGION              Region where the cluster is hosted

GCP_PROJECT             Your Google Cloud project ID