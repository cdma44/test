# ✅ Terraform Sentinel Policy for GCS Bucket Label Governance

## 🎯 Use Case

To enforce cost allocation and governance standards in cloud infrastructure, it's important to require specific labels (e.g., `cost-center`) on all Google Cloud Storage (GCS) buckets.

Using **Terraform Cloud Sentinel** (or **Checks** in newer Terraform Cloud versions), we can **prevent deployment** of any GCS bucket that is missing this required label.

This helps:
- Enforce tagging compliance.
- Enable accurate billing and cost attribution.
- Improve traceability of cloud resources.

---

## 🔐 Sentinel Policy Logic

Here is a simple **pseudo-code example** of a Sentinel policy that checks for a `cost-center` label on all `google_storage_bucket` resources:

```hcl
import "tfplan/v2" as tfplan

# Get all GCS bucket resources in the Terraform plan
gcs_buckets = filter tfplan.resource_changes as r {
  r.type is "google_storage_bucket" and
  (r.mode is "managed") and
  (r.change.actions contains "create" or r.change.actions contains "update")
}

# Check each bucket for the 'cost-center' label
valid_buckets = all gcs_buckets as bucket {
  labels = bucket.change.after.labels
  labels is not null and "cost-center" in labels
}

# Enforce the policy
main = rule {
  valid_buckets
}
