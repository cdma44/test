## GKE Secure Terraform Provisioning

### 🔐 Security Features

- **Workload Identity**: Securely binds Kubernetes Service Accounts to GCP Service Accounts, avoiding the need to mount JSON credentials. It ensures **least privilege** and simplifies rotation.

- **Network Policy**: Enabling Calico network policy allows restricting **pod-to-pod communication**, preventing lateral movement inside the cluster if a pod is compromised.

- **Master Authorized Networks**: Restricting access to the Kubernetes API server ensures that only **trusted IPs** (e.g., office network or CI/CD IPs) can communicate with the control plane.

---
