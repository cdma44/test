# Helm-J-1: Install Existing Chart (Simulated)

## Use Case

Simulate the installation of the official `bitnami/nginx` Helm chart into a Kubernetes namespace called `webserver`, overriding the service type to `LoadBalancer`.

## Helm Command

```bash
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update

helm install nginx-server bitnami/nginx \
  --namespace webserver \
  --create-namespace \
  --set service.type=LoadBalancer